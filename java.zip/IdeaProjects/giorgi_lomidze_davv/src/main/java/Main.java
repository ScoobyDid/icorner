import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.Random;


public class Main {

    private static final Logger logger = LogManager.getLogger(Main.class);



    public static void main(String[] args) {
        long[] fibonacci = getFibonacci(100);

        for (long currentFib : fibonacci) {
            System.out.println(currentFib);
        }

            Scanner newIntScanner = new Scanner(System.in);
            System.out.println("Enter integer: ");
            int num = newIntScanner.nextInt();
            long result = getFibonacciMember(num);
            logger.info(result);

            int magicNum = getMagicNum();
            logger.info("----- magicNum -----");
            logger.info(magicNum);

        Scanner magicIntScanner = new Scanner(System.in);
        logger.info("Enter magic integer:");
        int tries = 1;
        int guesseInt = magicIntScanner.nextInt();

        while(guesseInt != magicNum) {
            if(guesseInt >= magicNum) logger.info("Wrong number. entered number is HIGHER than magic number. enter again. ");
            else logger.info("Wrong number. entered number is LOWER than magic number. enter again. ");

            guesseInt = newIntScanner.nextInt();
            tries++;
        }

        logger.info("Correct!! Number of tries: " + tries);
    }



    public static long[] getFibonacci(int amount) {
        long[] nums = new long[amount];
        long prevNum = 0;
        long currNum = 1;
        long nextNum = prevNum + currNum;

        nums[0] = prevNum;
        nums[1] = currNum;
        nums[2] = nextNum;

        for (int i = 2; i < amount; i++) {
            prevNum = currNum;
            currNum = nextNum;
            nextNum = prevNum + currNum;
            nums[i] = nextNum;
        }

        return nums;
    }



    public static long getFibonacciMember(int num) {
        long prevNum = 0;
        long currNum = 1;
        long nextNum = prevNum + currNum;

        if(num == 0) return 0;
        else if(num == 1 || num == 2) return 1;

        for (int i = 2; i < num; i++) {
            prevNum = currNum;
            currNum = nextNum;
            nextNum = prevNum + currNum;
        }

        return nextNum;
    }



    public static int getMagicNum() {
        Random rand = new Random();
        int randInt = rand.nextInt(-14, 1488);
        return randInt;
    }
}
