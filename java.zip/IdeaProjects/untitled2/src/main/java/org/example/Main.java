package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;



public class Main {

    private static final Logger logger = LogManager.getLogger(Main.class);



    public static void main(String[] args) {

        Book book = new Book();
        book.name = "11.22.63";
        book.publisher = "Scribner";
        book.yearOfPublication = 2011;
        book.numberOfPages = 849;
        book.genre = Genre.FICTION;

        Author author = new Author();
        author.firstName = "Stephen";
        author.lastName = "King";
        author.placeOfBirth = "Portland";
        author.yearOfBirth = 1947;
        author.book = book;

        logger.info("author: {} {}", author.firstName, author.lastName);
        logger.info("born: {}, {}", author.yearOfBirth, author.placeOfBirth);
        logger.info("book: {}, {}", author.book.name, author.book.yearOfPublication);
        logger.info("pages: {}, genre: {}", author.book.numberOfPages, author.book.genre);



        Random random = new Random();
        int listSize = random.nextInt(6) + 15;
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < listSize; i++) {
            list.add(random.nextInt(79) + 10);
        }

        logger.info("list size: {}", list.size());
        logger.info("list: {}", list);



        int evenCount = 0, oddCount = 0;

        for (int num : list) {
            if (num % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
        }

        logger.info("even numbers: {}", evenCount);
        logger.info("odd numbers: {}", oddCount);



        if (list.size() >= 4) {
            list.remove(3);
        }
        if (list.size() >= 3) {
            list.remove(2);
        }

        logger.info("updated list: {}", list);

        list.clear();
    }
}
