package org.example;

public class Book {
    String name;
    String publisher;
    int yearOfPublication;
    int numberOfPages;
    Genre genre;
}
