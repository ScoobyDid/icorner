package org.example;

public class Author {
    String firstName;
    String lastName;
    String placeOfBirth;
    int yearOfBirth;
    Book book;
}
