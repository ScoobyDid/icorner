import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;  // Import the Scanner class

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
//
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
//        int length = 10;
//        int[] myArray = new int[length];
//        for(int i = 0; i < length; i++) {
//            Scanner newIntScanner = new Scanner(System.in);  // Create a Scanner object
//            System.out.println("Enter integer: ");
//            int newInt = newIntScanner.nextInt();
//            myArray[i] = newInt;
//        }
//
//        System.out.println("-------- array: --------");
//        for (int currentInt : myArray) {
//            System.out.println(currentInt);
//        }



        int length20 = 20;
        int[] myArray20 = new int[length20];
        Random rand = new Random();

        for (int i = 0; i < length20; i++) {
            int randInt = rand.nextInt(-88, 1000);
            myArray20[i] = randInt;
        }



        toAscending(myArray20);

        System.out.println("-------- array to ascending: --------");
        for (int currentInt : myArray20) {
            System.out.println(currentInt);
        }


        System.out.println("-------- median: --------");
        System.out.println(getMedianFromSortedArray(myArray20));



        int[][] matrix = {
            {4, 8, 19, 0},
            {-55, 934, 67, 1},
            {4, 7, 144, 88},
            {0, -123, -7, 1488},
        };

        System.out.println("-------- matrix: --------");
        printMatrix(matrix);




        int sum = getMatrixSum(matrix);
        System.out.println("-------- matrix sum: --------");
        System.out.println(sum);



        int[][] matrix2 = {
            {43, 81, 1, 10},
            {-5, 94, 7, 11},
            {43, 17, 14, 9},
            {-8, -13, 7, 1},
        };

        System.out.println("-------- matrix 2: --------");
        printMatrix(matrix2);

        int[][] summarizedMatrices = sumMatrices(matrix, matrix2);

        System.out.println("-------- summarized matrices: --------");
        printMatrix(summarizedMatrices);



        int sumUpp = sumDiagonalUpper(matrix2);
        System.out.println("-------- upper diagonal sum of matrix 2: --------");
        System.out.println(sumUpp);



        int sumLow = sumDiagonalLower(matrix2);
        System.out.println("-------- lower diagonal sum of matrix 2: --------");
        System.out.println(sumLow);



        int sumDiag = sumDiagonal(matrix2);
        System.out.println("-------- diagonal sum of matrix 2: --------");
        System.out.println(sumDiag);
    }



    public static void toAscending(int[] arr) {
        Arrays.sort(arr);
    }



    public static int getMedianFromSortedArray(int[] arr) {
        if(arr.length == 1) return arr[0];

        if(arr.length % 2 != 0) {
            int medianIndex = (arr.length - 1) / 2;
            return arr[medianIndex];
        }

        int index = arr.length / 2;
        int middle1 = arr[index];
        int middle2 = arr[index - 1];
        return (middle1 + middle2) / 2;
    }



    public static int getMatrixSum(int[][] matrix) {
        int sum = 0;
        for (int[] currentArr : matrix) {
            for (int currentInt : currentArr) {
                sum += currentInt;
            }
        }
        return sum;
    }



    public static int[][] sumMatrices(int[][] matrix1, int[][] matrix2) {
        int rows = matrix1.length;
        int cols = matrix1[0].length;

        int[][] resultMatrix = new int[rows][cols];

        for (int i = 0; i < rows; i++) {
            int[] currentArr1 = matrix1[i];
            int[] currentArr2 = matrix2[i];

            for (int j = 0; j < cols; j++) {
                int currentNum1 = currentArr1[j];
                int currentNum2 = currentArr2[j];
                resultMatrix[i][j] = currentNum1 + currentNum2;
            }
        }

        return resultMatrix;
    }


    public static int sumDiagonalUpper(int[][] matrix) {
        return sumMatrixByDiagonal(matrix, "upper");
    }



    public static int sumDiagonalLower(int[][] matrix) {
        return sumMatrixByDiagonal(matrix, "lower");
    }



    public static int sumDiagonal(int[][] matrix) {
        return sumMatrixByDiagonal(matrix, "diagonal");
    }




    public static int sumMatrixByDiagonal(int[][] matrix, String approach) {
        // rows must be = cols
        int dimension = matrix.length;
        int sum = 0;

        for (int i = 0; i < dimension ; i++) {
            int[] currentArr = matrix[i];
            for (int j = 0; j < dimension; j++) {
                if(approach == "diagonal" && i != j
                    || approach == "upper" && i >= j
                    || approach == "lower" && i <= j) {
                    continue;
                }
                int upperDiagonalNum = currentArr[j];
                sum += upperDiagonalNum;
            }
        }
        return sum;
    }



    public static void printMatrix(int[][] matrix) {
        for (int[] currentArr : matrix) {
            String currentStr = "";
            for (int currentInt : currentArr) {
                currentStr += currentInt + ", ";
            }

            // remove ", " in the end
            System.out.println(currentStr.substring(0, currentStr.length() - 2));
        }
    }
}